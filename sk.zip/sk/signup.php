<!DOCTYPE html>
<html lang="en">
<head>
	<title>Create New Account</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UV-Compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width, initial-scals=1.0">
	<link rel="stylesheet" href="css/signup.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
	
	<div class="signup-form">
		<form action="" method="post">
			<div class="form-header">
				<h2>Sign Up</h2>
				<p>Fill out this form and chating with your friends<p>
			</div>
			
			<div class="form-group">
				<label for="uname">User Name</label>
				<input class="form-control" type="text" name="user_name" placeholder="username" autocomplete="of" required id="uname">
			</div>
			
			<div class="form-group">
				<label for="upass">Password</label>
				<input class="form-control" type="password" name="user_pass" placeholder="password" autocomplete="of" required id="upass">
			</div>
			
			<div class="form-group">
				<label for="email">Email Address</label>
				<input class="form-control" type="email" name="user_email" placeholder="someone@gmail.com" autocomplete="of" required id="email">
			</div>
			
			<div class="form-group">
				<label for="country">Country</label>
				<select name="user_country" id="country" class="form-control">
				    <option disabled="">--Select a Country--</option>
					<option>Bangladesh</option>
					<option>Pakistan</option>
					<option>India</option>
					<option>USA</option>
					<option>Chin</option>
					<option>Austroliya</option>
					<option>France</option>
					<option>Rasia</option>
				</select>
			</div>
			
				<div class="form-group">
				<label for="gender">Gender</label>
				<select name="user_gender" id="gender" class="form-control">
				    <option disabled="">--Select your Gender--</option>
					<option>Male</option>
					<option>Female</option>
					<option>Others</option>
				</select>
			</div>
			
			<div class="form-group">
				<lable class="checkbox-inline"><input type="checkbox" required> I accept the <a href="#">Terms of Use</a> &amp; <a href="">Privacy Policy</a></lable>
			</div>
			<div class="form-group">
				<button class="btn btn-primary btn-block btn-lg" name="sign_up">Sign Up</button>
			</div>
						
			<div class="text-center small" style="color:#444;">Already have an account?  <a href="signin.php">Signin here</a></div>
			<?php include("signup_user.php"); ?>
		</form>

	 </div>
	
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>