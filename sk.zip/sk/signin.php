<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login To Your Account </title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UV-Compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width, initial-scals=1.0">
	<link rel="stylesheet" href="css/signin.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
	<div class="signin-form">
		<form action="" method="post">
			<div class="form-header">
				<h2>Sign In</h2>
				<p>Login to MyChat<p>
			</div>
			<div class="form-group">
				<label for="email">Email</label>
				<input class="form-control" type="email" name="email" placeholder="user@gmail.com" autocomplete="of" required id="email">
			</div>
			<div class="form-group">
				<label for="pass">Password</label>
				<input class="form-control" type="password" name="pass" placeholder="password" autocomplete="of" required id="pass">
			</div>
			<div class="small text-center">Forgot Password? <a href="forgot_pass.php">Click Here</a></div><br>
			<div class="form-group">
				<button class="btn btn-primary btn-block btn-lg" name="sign_in">Sign in</button>
			</div>
			<?php include("signin_user.php"); ?>
			
			<div class="text-center small" style="color:#444;">Don't have an account?  <a href="signup.php">Create one</a></div>
		</form>
	 </div>
	
	
	
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>