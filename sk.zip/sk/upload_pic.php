<!DOCTYPE html>
<?php
session_start();
include("include/connection.php");
include("include/header.php");
if(!isset($_SESSION['user_email'])){
	 header("location:signin.php");
}
else{ 
?>
<html lang="en">
	<head>
		<title>Change Profile Picture</title>
		<meta charset="UTF-8">
		<meta http-equiv="X-UV-Compatible" content="IE-edge">
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="font/css/all.min.css">
		
		<style>
			.card{
			box-shadow: 0 2px 8px 0 rgba(0,0,0,.2);
			max-width: 350px;
			margin: auto;
			text-align: center;
			background: #8bc34a!important;
			border: none !important;
			}
			.card img{
				height: 250px;
			}
			button{
				border: none;
				outline: 0;
				padding: 4px;
				background: #000;
				color: #fff;
				text-align: center;
				float: right;
				font-size: 14px;
			}
			input{
				width: 50% !important;
				margin: auto;
				float: left;
			}
		</style>
	</head>
	<body>
	      <?php
	            $user = $_SESSION['user_email'];
	            $get_user = "select * from users where user_email='$user'";
	            $run_user = mysqli_query($con,$get_user);
	           
	            $row = mysqli_fetch_array($run_user);
	              
	            $user_name = $row['user_name'];
				$user_profile = $row['user_profile'];
	            
	 			echo "
				<div class='card p-3'> 
				   <img class='img-fluid' src='$user_profile'>
				   <h1 class='pt-3'>$user_name</h1>
				   <form method='post' enctype='multipart/form-data'>
					    <input  type='file' name='u_img' size='60'>
					    <button type='submit'  name='update'><i class='fa fa-user'></i> Update Profile</button>
				   </form>
				</div><br>
			    ";
	 			
	 			if(isset($_POST['update'])){
					$u_img = $_FILES['u_img']['name'];
					$img_tmp = $_FILES['u_img']['tmp_name'];
					$random_number = rand(1,100);
					if($u_img == ""){
						echo "<script>alert('pleace upload yuor profile pic')</script>";
						echo "<script>window.open('upload_pic.php','_self')</script>";
						exit();
					}
					else{
						move_uploaded_file($img_tmp,"img/$u_img");
						
						$update_pic = "update users set user_profile='img/$u_img' where user_email='$user'";
						
						$run = mysqli_query($con,$update_pic);
						
						if($run){
							echo "<script>alert('Profile pic upload successfull....')</script>";
							echo "<script>window.open('upload_pic.php','_self')</script>";
						}
					}
				}
	          
	       ?>
	

		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</body>
</html>
<?php } ?>
