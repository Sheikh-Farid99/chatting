<!DOCTYPE html>
<?php
session_start();
 include("find_friends_function.php");
if(!isset($_SESSION['user_email'])){
	 header("location:signin.php");
}
else{
	
?>
<html lang="en">
<head>
    <title>Find-Friends</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UV-Compatible" content="IE-edge">
	<link rel="stylesheet" href="../css/find_friends.css">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../font/css/all.min.css">
</head>
<body>
	<nav class="bg-dark text-center py-4 fixed-top">
	   <div class="row">
			<div class="col-sm-6 col-xs-6">
			    <?php
					$user = $_SESSION['user_email'];
					$get_user = "select * from users where user_email='$user'";
					$run_user = mysqli_query($con,$get_user);
					$row = mysqli_fetch_array($run_user);

					$user_name = $row['user_name'];
					echo "<a style='text-decoration:none; font-size:20px;' href='../index.php?user_name=$user_name'>Home<a/>";
				?>
			</div>
			<div class="col-sm-6 col-xs-6">
				<a style="text-decoration:none; font-size:20px;" href="../account_setting.php">Setting</a>
			</div>
	  </div>
	   	
	</nav><br>
	
	<div class="row">
		<div class="col-sm-4">
			
		</div>
		<div class="col-sm-4">
			<form action="" class="search_form text-center">
				<input class="bg-dark" type="text" name="search_query" placeholder="search friends" autocomplete="of" required>
				<button class="btn btn-outline-dark" type="submit" name="search_btn">Search</button>
			</form>
		</div>
		<div class="col-sm-4">
			
		</div>
	</div><br>
	<?php search_user()?>
	
	
	<script src="../js/jquery.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
</body>
</html>
<?php } ?>