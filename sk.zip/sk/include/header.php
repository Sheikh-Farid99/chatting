<nav class="bg-dark text-center py-4">
   <div class="row">
		<div class="col-sm-6 col-xs-6">
			<?php
				$user = $_SESSION['user_email'];
				$get_user = "select * from users where user_email='$user'";
				$run_user = mysqli_query($con,$get_user);
				$row = mysqli_fetch_array($run_user);

				$user_name = $row['user_name'];
				echo "<a style='text-decoration:none; font-size:20px;' href='index.php?user_name=$user_name'>Home<a/>";
			?>
		</div>
		<div class="col-sm-6 col-xs-6">
			<a style="text-decoration:none; font-size:20px;" href="account_setting.php">Setting</a>
		</div>
  </div>
</nav><br>