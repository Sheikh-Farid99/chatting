<?php

$con=mysqli_connect("localhost","id13951375_sfarid","SSfarid498@#$","id13951375_farid") or die("Connection was not established");

?>