<?php
$con=mysqli_connect("localhost","id13951375_sfarid","SSfarid498@#$","id13951375_farid") or die("Connection was not established");

function search_user(){
	global $con;
	
	if(isset($_GET['search_btn'])){
		$search_query = htmlentities($_GET['search_query']);
		
		$get_user = "select * from users where user_name like '%$search_query%' or user_country like '%$search_query%'";
		
	}
	else{
		$get_user = "SELECT * FROM USERS order by user_name, user_country DESC LIMIT 5";
    }
	$run_user = mysqli_query($con,$get_user);
	
	while($row = mysqli_fetch_array($run_user)){
		$user_name = $row['user_name'];
		$user_profile = $row['user_profile'];
		$country = $row['user_country'];
		$gender = $row['user_gender'];
		
		echo "
			<div class='card p-3'> 
			   <img class='img-fluid' src='../$user_profile'>
			   <h1 class='pt-3'>$user_name</h1>
			   <p>$country</p>
			    <p class='pb-2'>$gender</p>
			   <form method='post'> 
			      <P><button class='btn btn-success btn-block px-4' name='add'>Chat with $user_name</button></p>
			   </form>
			</div><br>
		";
		
		if(isset($_POST['add'])){
			echo "<script>window.open('../index.php?user_name=$user_name','_self')</script>";
		}
	}
}
?>