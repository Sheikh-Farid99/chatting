<?php

$con=mysqli_connect("localhost","id13951375_sfarid","SSfarid498@#$","id13951375_farid") or die("Connection was not established");

$user = "select * from users";

$run_user = mysqli_query($con,$user);

while($row_user= mysqli_fetch_array($run_user)){
	$user_id = $row_user['user_id'];
	$user_name = $row_user['user_name'];
	$user_profile = $row_user['user_profile'];
	$log_in = $row_user['log_in'];

	echo "<li>
	     <div class='chat-left-img'>
		    <img src='$user_profile'>
		 </div>
		  <div class='chat-left-details'>
		    <p><a href='index.php?user_name=$user_name'>$user_name</a></p>";
			if($log_in == "online"){
			   echo '<span><i class="fa fa-circle"></i> online</span>';
			}
			else{
			   echo '<span><i class="fa fa-circle-o"></i> offline</span>';
			}
	        "
			</div>
		</li>
			";
			
}

?>